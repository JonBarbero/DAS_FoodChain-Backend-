<?php

$con=mysqli_connect("localhost","Xjbarbero004","*0My0ui41hu","Xjbarbero004_foodorder");
if(!$con)
{
    echo "Connection Not Established";
}




?>
